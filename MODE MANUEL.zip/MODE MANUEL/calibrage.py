#!/usr/bin/env python3
import time

from pyniryo import NiryoRobot, NiryoRobotException
from HotasMode.hotas.mapper import HotasMapper  # <-- selon ton arbo (HotasMode/hotas/mapper.py)

# ======================
# PARAMS TEMPS RÉEL (BRAS ONLY)
# ======================
CONTROL_HZ = 10.0   # puis 10 puis 12
DT = 1.0 / CONTROL_HZ

# ======================
# PARAMS COMMANDE
# ======================
DEADZONE = 0.05
EXPO = 1.6
BASE_SPEED = 4    # puis 4.2 si trop lent           
ARM_MAX_VELOCITY_PERCENT = 100    # 0..100


EPS_MOVE = 0.005  # puis 0.006 puis 0.008

# ======================
# ROBOT
# ======================
ROBOT_IP = "10.10.10.10"

# ======================
# OUTILS
# ======================
def apply_deadzone(v: float, dz: float) -> float:
    return 0.0 if abs(v) < dz else v

def apply_expo(v: float, expo: float) -> float:
    s = 1.0 if v >= 0 else -1.0
    return s * (abs(v) ** expo)

def clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))

def vec_norm_inf(vec):
    return max(abs(x) for x in vec)

def max_abs_diff(a, b):
    return max(abs(x - y) for x, y in zip(a, b))

# ======================
# MAPPING HOTAS -> qdot
# ======================
def compute_qdot(state, gain: float = 1.0):
    """
    Mapping demandé :
    - Twist joystick => Base gauche/droite (J1)
    - Haut/Bas joystick => Monter/descendre (J2)
    - Gauche/Droite joystick => Tourner avant-bras (J3)
    - HAT => Poignet (J4) + (option) J5
    """
    x = apply_expo(apply_deadzone(state.x, DEADZONE), EXPO)
    y = apply_expo(apply_deadzone(state.y, DEADZONE), EXPO)
    tw = apply_expo(apply_deadzone(state.twist, DEADZONE), EXPO)

    hat = state.joy_dir  # "UP/DOWN/LEFT/RIGHT/NONE" (selon ton mapper)

    qdot = [0.0] * 6

    # Analogique : BASE / EPAULE / AVANT-BRAS
    qdot[0] = (+tw) * BASE_SPEED * gain   # J1 = base (twist)
    qdot[1] = (-y)  * BASE_SPEED * gain   # J2 = épaule (up/down)
    qdot[2] = (+x)  * BASE_SPEED * gain   # J3 = avant-bras (left/right)

    # Digital via HAT : POIGNET (sans écraser J3)
    step = 0.55 * BASE_SPEED * gain
    if hat == "UP":
        qdot[3] = +step   # J4
    elif hat == "DOWN":
        qdot[3] = -step
    elif hat == "RIGHT":
        qdot[4] = +step   # J5 (option)
    elif hat == "LEFT":
        qdot[4] = -step

    # Limite globale si plusieurs axes à fond
    m = vec_norm_inf(qdot)
    limit = BASE_SPEED * gain
    if m > limit and m > 1e-9:
        scale = limit / m
        qdot = [v * scale for v in qdot]

    return qdot

# ======================
# PINCE (trigger = fermer, demo)
# ======================
def gripper_command(robot, state, last):
    trig = getattr(state, "trigger", 0)
    if trig == 1 and last["trigger"] == 0:
        try:
            robot.close_gripper()
        except Exception:
            pass
    last["trigger"] = trig

# ======================
# MAIN
# ======================
def main():
    # HOTAS
    mapper = HotasMapper(calibrate=True, print_devices=True)

    # ROBOT : connexion déjà faite par le constructeur dans ta version
    robot = NiryoRobot(ROBOT_IP)
    robot.calibrate_auto()
    robot.set_arm_max_velocity(ARM_MAX_VELOCITY_PERCENT)

    print(f"[RUN] Teleop bras @ {CONTROL_HZ:.1f} Hz | DT={DT:.3f}s")
    last = {"trigger": 0}
    t_prev = time.time()

    try:
        while True:
            t0 = time.time()
            dt = t0 - t_prev
            t_prev = t0

            # garde-fou sur dt (évite les énormes pas en cas de lag)
            dt = clamp(dt if dt > 0 else DT, 0.001, 0.10)

            # lecture hotas
            s = mapper.read()

            # bras only => gain fixe
            gain = 1.0

            # vitesses joints
            qdot = compute_qdot(s, gain)

            # si aucune commande => pas de spam
            if vec_norm_inf(qdot) < 1e-4:
                gripper_command(robot, s, last)
                time.sleep(max(0.0, DT - (time.time() - t0)))
                continue

            # lecture joints actuels
            q = robot.get_joints()

            # intégration position cible
            q_target = [qi + vi * dt for qi, vi in zip(q, qdot)]

            # seuil anti-micro-commandes (fluidité)
            if max_abs_diff(q_target, q) < EPS_MOVE  :  # ~0.23°
                gripper_command(robot, s, last)
                time.sleep(max(0.0, DT - (time.time() - t0)))
                continue

            # envoi
            try:
                robot.move_joints(*q_target)
            except NiryoRobotException as e:
                print("[MOVE WARN]", e)

            # pince
            gripper_command(robot, s, last)

            # timing boucle
            time.sleep(max(0.0, DT - (time.time() - t0)))

    except KeyboardInterrupt:
        print("\n[STOP] user")
    finally:
        try:
            robot.close_connection()
        except Exception:
            pass

if __name__ == "__main__":
    main()