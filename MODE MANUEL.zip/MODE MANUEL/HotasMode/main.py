import time
from hotas import HotasMapper

PRINT_HZ = 2.0
DT = 1.0 / PRINT_HZ

def main():
    mapper = HotasMapper(calibrate=True, print_devices=True)

    while True:
        s = mapper.read()
        print(
            f"JOY x={s.x:+.2f} y={s.y:+.2f} tw={s.twist:+.2f} | "
            f"HAT={s.joy_hat}({s.joy_dir}) | TRIG={s.trigger} | "
            f"MANUAL={s.manual_toggle} | ESTOP={s.estop_toggle} || "
            f"THR raw={s.throttle_raw:+.2f} speed={s.throttle_speed:.2f} | "
            f"DIR={s.direction} thr_hat={s.thr_hat}"
        )
        time.sleep(DT)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStop.")