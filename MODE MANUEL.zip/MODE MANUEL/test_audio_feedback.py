import time

from FeedBackMode.feedback import RobotFeedback


class DummyRobot:
    """
    Faux robot pour tester uniquement l'audio PC et éviter
    toute dépendance au Niryo pendant les tests.
    """
    def led_ring_solid(self, color):
        print(f"[DUMMY ROBOT] led_ring_solid({color})")

    def led_ring_flashing(self, color, period=0.3, iterations=0, wait=False):
        print(f"[DUMMY ROBOT] led_ring_flashing({color}, period={period}, iterations={iterations}, wait={wait})")

    def led_ring_turn_off(self):
        print("[DUMMY ROBOT] led_ring_turn_off()")

    def say(self, text, lang):
        print(f"[DUMMY ROBOT] say(lang={lang}) -> {text}")

    def set_volume(self, volume_pct):
        print(f"[DUMMY ROBOT] set_volume({volume_pct})")

    def get_sounds(self):
        return []

    def play_sound(self, sound_name, wait_end=False):
        print(f"[DUMMY ROBOT] play_sound({sound_name}, wait_end={wait_end})")

    def stop_sound(self):
        print("[DUMMY ROBOT] stop_sound()")


def main():
    robot = DummyRobot()

    feedback = RobotFeedback(
        robot=robot,
        use_led=False,
        use_voice=False,
        use_robot_sound=False,
        use_pc_sound=True,
        sounds_dir="SON_FEEDBACK",
        pc_volume=1.0
    )

    print()
    print("=== TEST AUDIO FEEDBACK ===")
    print("[TEST] Sons détectés :", feedback.list_sounds())
    print()

    tests = [
        ("manual_on", "Mode manuel activé"),
        ("manual_off", "Mode manuel désactivé"),
        ("estop_on", "Stop urgence activé"),
        ("estop_off", "Stop urgence désactivé"),
        ("conv_on", "Convoyeur activé"),
        ("conv_forward", "Convoyeur en avant"),
        ("conv_backward", "Convoyeur en arrière"),
        ("conv_off", "Convoyeur désactivé"),
    ]

    for key, label in tests:
        print(f"[TEST] Lecture : {label} -> clé='{key}'")
        ok = feedback.play_pc_sound(key, wait_end=False, stop_previous=True)
        print(f"[TEST] Résultat = {ok}")
        time.sleep(3)

    print()
    print("[TEST] Fin du test audio.")


if __name__ == "__main__":
    main()