import time
import threading

from pyniryo import (
    NiryoRobot,
    NiryoRobotException,
    JointsPosition,
    ConveyorDirection,
)
from HotasMode.hotas import HotasMapper
from FeedBackMode.feedback import RobotFeedback

# ======================
# PARAMS TEMPS RÉEL
# ======================
HOTAS_HZ = 200.0
HOTAS_DT = 1.0 / HOTAS_HZ

ROBOT_HZ = 8.0
ROBOT_DT = 1.0 / ROBOT_HZ

CONVEYOR_HZ = 2.0
CONVEYOR_DT = 1.0 / CONVEYOR_HZ

# ======================
# PARAMS COMMANDE BRAS
# ======================
DEADZONE = 0.05
EXPO = 1.6
BASE_SPEED = 4.0
ARM_MAX_VELOCITY_PERCENT = 100
EPS_MOVE = 0.0035

INV_TWIST = True
INV_Y = False
INV_X = True

# ======================
# PARAMS PINCE / MODES
# ======================
GRIPPER_COOLDOWN = 0.45
MODE_COOLDOWN = 0.40
ESTOP_COOLDOWN = 0.40

HAT_MAP = {
    "UP": "UP",
    "DOWN": "DOWN",
    "LEFT": "LEFT",
    "RIGHT": "RIGHT",
    "NONE": "NONE",
}

ROBOT_IP = "10.10.10.10"

# ======================
# PARTAGE ETAT
# ======================
shared = {"state": None, "stop": False, "lock": threading.Lock()}

# ======================
# ETAT PINCE
# ======================
gripper_state = {
    "closed": False,
    "busy": False,
    "last_trigger": False,
    "last_toggle_time": 0.0,
}

# ======================
# ETAT SYSTEME
# ======================
system_state = {
    "manual_enabled": True,
    "estop_active": False,
    "last_manual_btn": False,
    "last_estop_btn": False,
    "last_manual_toggle_time": 0.0,
    "last_estop_toggle_time": 0.0,
}


# ======================
# OUTILS
# ======================
def apply_deadzone(v: float, dz: float) -> float:
    return 0.0 if abs(v) < dz else v


def apply_expo(v: float, expo: float) -> float:
    s = 1.0 if v >= 0 else -1.0
    return s * (abs(v) ** expo)


def vec_norm_inf(vec) -> float:
    return max(abs(x) for x in vec)


def max_abs_diff(a, b) -> float:
    return max(abs(x - y) for x, y in zip(a, b))


def safe_stop_outputs(robot, conveyor_id):
    try:
        if conveyor_id is not None:
            robot.stop_conveyor(conveyor_id)
    except Exception as e:
        print("[SAFE STOP WARN]", e)


# ======================
# MAPPING HOTAS -> qdot
# ======================
def compute_qdot(state, gain: float = 1.0):
    x_raw = getattr(state, "x", 0.0)
    y_raw = getattr(state, "y", 0.0)
    tw_raw = getattr(state, "twist", 0.0)

    if INV_X:
        x_raw = -x_raw
    if INV_Y:
        y_raw = -y_raw
    if INV_TWIST:
        tw_raw = -tw_raw

    x = apply_expo(apply_deadzone(x_raw, DEADZONE), EXPO)
    y = apply_expo(apply_deadzone(y_raw, DEADZONE), EXPO)
    tw = apply_expo(apply_deadzone(tw_raw, DEADZONE), EXPO)

    hat_in = getattr(state, "joy_dir", "NONE")
    hat = HAT_MAP.get(hat_in, "NONE")

    qdot = [0.0] * 6

    # Joystick -> J1/J2/J3
    qdot[0] = tw * BASE_SPEED * gain
    qdot[1] = y * BASE_SPEED * gain
    qdot[2] = x * BASE_SPEED * gain

    # Hat joystick -> J4/J5
    step = 0.55 * BASE_SPEED * gain
    if hat == "UP":
        qdot[4] = +step
    elif hat == "DOWN":
        qdot[4] = -step
    elif hat == "RIGHT":
        qdot[3] = +step
    elif hat == "LEFT":
        qdot[3] = -step

    # Limite globale
    m = vec_norm_inf(qdot)
    limit = BASE_SPEED * gain
    if m > limit and m > 1e-9:
        scale = limit / m
        qdot = [v * scale for v in qdot]

    return qdot


# ======================
# CONVEYOR DETECT
# ======================
def detect_conveyor(robot):
    conv_ids = []
    try:
        conv_ids = robot.get_connected_conveyors_id()
    except Exception:
        conv_ids = []

    if conv_ids:
        return conv_ids[0]

    cid = None
    try:
        cid = robot.set_conveyor()
    except Exception:
        cid = None

    try:
        conv_ids = robot.get_connected_conveyors_id()
    except Exception:
        conv_ids = []

    if cid is not None:
        return cid
    if conv_ids:
        return conv_ids[0]
    return None


# ======================
# PINCE
# ======================
def safe_toggle_gripper(robot):
    if gripper_state["busy"]:
        return

    gripper_state["busy"] = True
    try:
        if gripper_state["closed"]:
            print("[GRIPPER] opening...")
            robot.open_gripper()
            gripper_state["closed"] = False
            print("[GRIPPER] opened")
        else:
            print("[GRIPPER] closing...")
            robot.close_gripper()
            gripper_state["closed"] = True
            print("[GRIPPER] closed")
    except Exception as e:
        print("[GRIPPER WARN]", e)
    finally:
        gripper_state["busy"] = False
        gripper_state["last_toggle_time"] = time.time()


# ======================
# MODES / ESTOP
# ======================
def handle_mode_buttons(robot, conveyor_id, s, feedback):
    manual_now = bool(getattr(s, "manual_toggle", False))
    estop_now = bool(getattr(s, "estop_toggle", False))

    manual_prev = system_state["last_manual_btn"]
    estop_prev = system_state["last_estop_btn"]

    manual_rising = manual_now and not manual_prev
    estop_rising = estop_now and not estop_prev

    now = time.time()

    manual_ready = (now - system_state["last_manual_toggle_time"]) >= MODE_COOLDOWN
    estop_ready = (now - system_state["last_estop_toggle_time"]) >= ESTOP_COOLDOWN

    if manual_rising and manual_ready and not system_state["estop_active"]:
        system_state["manual_enabled"] = not system_state["manual_enabled"]
        system_state["last_manual_toggle_time"] = now

        safe_stop_outputs(robot, conveyor_id)

        if system_state["manual_enabled"]:
            print("[MODE] manual ENABLED")
            feedback.manual_on()
        else:
            print("[MODE] manual DISABLED")
            feedback.manual_off()

    if estop_rising and estop_ready:
        system_state["estop_active"] = not system_state["estop_active"]
        system_state["last_estop_toggle_time"] = now

        safe_stop_outputs(robot, conveyor_id)

        if system_state["estop_active"]:
            print("[ESTOP] ACTIVATED")
            feedback.estop_on()
        else:
            print("[ESTOP] RELEASED")
            feedback.estop_off(system_state["manual_enabled"])

    system_state["last_manual_btn"] = manual_now
    system_state["last_estop_btn"] = estop_now


# ======================
# THREAD ROBOT
# ======================
def robot_loop(robot, conveyor_id, feedback):
    last_axes_dbg = 0.0
    last_arm_time = 0.0
    last_conv_time = 0.0

    conv_enabled = False
    last_conv_cmd = {"on": None, "speed": None, "dir": None}

    while True:
        with shared["lock"]:
            if shared["stop"]:
                break
            s = shared["state"]

        if s is None:
            time.sleep(0.01)
            continue

        now = time.time()

        # ======================
        # 0) GESTION MODE / ESTOP
        # ======================
        handle_mode_buttons(robot, conveyor_id, s, feedback)

        manual_enabled = system_state["manual_enabled"]
        estop_active = system_state["estop_active"]

        # Si stop ou manuel OFF => rien ne bouge
        if estop_active or not manual_enabled:
            if (now - last_axes_dbg) > 0.5:
                print(
                    "[DBG SAFE]",
                    "manual_enabled=", manual_enabled,
                    "estop_active=", estop_active,
                    "| manual_toggle=", getattr(s, "manual_toggle", None),
                    "estop_toggle=", getattr(s, "estop_toggle", None),
                    "| conv_enabled=", conv_enabled,
                    "conv_id=", conveyor_id,
                )
                last_axes_dbg = now

            time.sleep(0.005)
            continue

        # ======================
        # 1) BRAS
        # ======================
        if (now - last_arm_time) >= ROBOT_DT:
            last_arm_time = now

            qdot = compute_qdot(s, gain=1.0)
            qdot_max = vec_norm_inf(qdot)

            if qdot_max >= 1e-4:
                try:
                    q = list(robot.get_joints())
                    q_target = [qi + vi * ROBOT_DT for qi, vi in zip(q, qdot)]

                    diff = max_abs_diff(q_target, q)
                    if diff >= EPS_MOVE:
                        robot.move(JointsPosition(*q_target))
                except NiryoRobotException as e:
                    print("[MOVE WARN]", e)
                except Exception as e:
                    print("[MOVE ERR]", e)

        # ======================
        # 2) TAPIS
        # ======================
        if conveyor_id is not None and (now - last_conv_time) >= CONVEYOR_DT:
            last_conv_time = now

            thr_hat = getattr(s, "thr_hat", (0, 0))
            if thr_hat is None or len(thr_hat) != 2:
                thr_hat = (0, 0)

            _, hy = thr_hat

            # ON / OFF par hat vertical du throttle
            if hy > 0:
                conv_enabled = True
            elif hy < 0:
                conv_enabled = False

            speed01 = float(getattr(s, "throttle_speed", 0.0) or 0.0)
            speed_pct = max(0, min(100, int(speed01 * 100)))

            thr_dir = getattr(s, "direction", "FWD")
            conv_dir = (
                ConveyorDirection.FORWARD
                if thr_dir == "FWD"
                else ConveyorDirection.BACKWARD
            )

            conv_on = bool(conv_enabled and speed_pct > 0)

            prev_on = last_conv_cmd["on"]
            prev_dir = last_conv_cmd["dir"]

            state_changed = (
                prev_on != conv_on
                or last_conv_cmd["speed"] != speed_pct
                or prev_dir != thr_dir
            )

            if state_changed:
                try:
                    robot.control_conveyor(conveyor_id, conv_on, speed_pct, conv_dir)

                    # --- sons uniquement sur changements utiles ---
                    if prev_on != conv_on:
                        if conv_on:
                            print("[AUDIO EVENT] conveyor ON")
                            feedback.conveyor_on()
                        else:
                            print("[AUDIO EVENT] conveyor OFF")
                            feedback.conveyor_off()

                    # annoncer la direction seulement si le tapis est ON
                    # soit quand il démarre, soit quand la direction change pendant qu'il tourne
                    if conv_on:
                        if prev_on != conv_on or prev_dir != thr_dir:
                            if thr_dir == "FWD":
                                print("[AUDIO EVENT] conveyor FORWARD")
                                feedback.conveyor_forward()
                            else:
                                print("[AUDIO EVENT] conveyor BACKWARD")
                                feedback.conveyor_backward()

                    last_conv_cmd = {
                        "on": conv_on,
                        "speed": speed_pct,
                        "dir": thr_dir,
                    }

                    print(f"[CONV] on={conv_on} speed={speed_pct}% dir={thr_dir} hat={thr_hat}")

                except Exception as e:
                    print("[CONV WARN]", e)

        # ======================
        # 3) PINCE
        # ======================
        trigger_now = bool(getattr(s, "trigger", False))
        trigger_prev = gripper_state["last_trigger"]

        rising_edge = trigger_now and not trigger_prev
        enough_time = (time.time() - gripper_state["last_toggle_time"]) >= GRIPPER_COOLDOWN

        if rising_edge and enough_time and not gripper_state["busy"]:
            safe_toggle_gripper(robot)

        gripper_state["last_trigger"] = trigger_now

        # ======================
        # DBG
        # ======================
        if (now - last_axes_dbg) > 0.5:
            print(
                "[DBG]",
                "x=", getattr(s, "x", None),
                "y=", getattr(s, "y", None),
                "twist=", getattr(s, "twist", None),
                "hat=", getattr(s, "joy_dir", None),
                "| thr_speed=", getattr(s, "throttle_speed", None),
                "direction=", getattr(s, "direction", None),
                "thr_hat=", getattr(s, "thr_hat", None),
                "trigger=", getattr(s, "trigger", None),
                "| manual_toggle=", getattr(s, "manual_toggle", None),
                "estop_toggle=", getattr(s, "estop_toggle", None),
                "| manual_enabled=", system_state["manual_enabled"],
                "estop_active=", system_state["estop_active"],
                "| conv_enabled=", conv_enabled,
                "conv_id=", conveyor_id,
                "| gripper_closed=", gripper_state["closed"],
                "gripper_busy=", gripper_state["busy"],
            )
            last_axes_dbg = now

        time.sleep(0.005)


# ======================
# ACCUEIL OPERATEUR
# ======================
def choose_operator():
    operators = {
        "1": ("naoufel", "Naoufel"),
        "2": ("yasmine", "Yasmine"),
        "3": ("doussouba", "Doussouba"),
        "4": ("emmanuel", "Emmanuel"),
        "5": ("amadou", "Amadou"),
    }

    print()
    print("=== Choix de l'opérateur ===")
    print("1 - Naoufel")
    print("2 - Yasmine")
    print("3 - Doussouba")
    print("4 - Emmanuel")
    print("5 - Amadou")

    while True:
        choice = input("Entrez 1 / 2 / 3 / 4 / 5 : ").strip()
        if choice in operators:
            return operators[choice]
        print("[INPUT WARN] Choix invalide.")

# ======================
# MAIN
# ======================
def main():
    mapper = HotasMapper(calibrate=True, print_devices=True)

    operator_key, operator_name = choose_operator()
    print(f"[OPERATOR] Opérateur sélectionné : {operator_name}")

    robot = NiryoRobot(ROBOT_IP)
    robot.set_learning_mode(False)
    robot.set_arm_max_velocity(ARM_MAX_VELOCITY_PERCENT)

    feedback = RobotFeedback(
        robot,
        use_led=True,
        use_voice=False,
        use_robot_sound=False,
        use_pc_sound=True,
        sounds_dir="SON_FEEDBACK",
        pc_volume=0.7
    )

    try:
        feedback.set_pc_volume(0.7)
    except Exception as e:
        print("[FEEDBACK VOLUME WARN]", e)

    try:
        feedback.welcome_user(operator_key)
        time.sleep(4)
    except Exception as e:
        print("[WELCOME WARN]", e)

    # Init pince ouverte au démarrage
    try:
        print("[INIT] opening gripper...")
        robot.open_gripper()
        gripper_state["closed"] = False
        print("[INIT] gripper opened")
    except Exception as e:
        print("[INIT GRIPPER WARN]", e)

    conveyor_id = detect_conveyor(robot)
    print(f"[CONV] detected id = {conveyor_id}")

    try:
        feedback.manual_on()
    except Exception as e:
        print("[FEEDBACK INIT WARN]", e)

    print("[RUN] Bras + Conveyor + Gripper + ManualMode + EStop ready")

    # Optionnel : afficher les sons dispos sur le robot
    try:
        sounds = feedback.list_sounds()
        print("[SOUNDS AVAILABLE]", sounds)
    except Exception as e:
        print("[SOUNDS LIST WARN]", e)

    th = threading.Thread(target=robot_loop, args=(robot, conveyor_id, feedback), daemon=True)
    th.start()

    try:
        while True:
            s = mapper.read()
            with shared["lock"]:
                shared["state"] = s
            time.sleep(HOTAS_DT)
    except KeyboardInterrupt:
        print("\n[STOP] user")
    finally:
        with shared["lock"]:
            shared["stop"] = True

        th.join(timeout=1.0)

        try:
            safe_stop_outputs(robot, conveyor_id)
        except Exception:
            pass

        try:
            feedback.led_off()
            feedback.stop_pc_sound()
        except Exception:
            pass

        try:
            robot.close_connection()
        except Exception:
            pass


if __name__ == "__main__":
    main()