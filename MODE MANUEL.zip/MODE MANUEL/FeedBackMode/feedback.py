from .local_audio_manager import AudioManager


class RobotFeedback:
    LANG_EN = 0
    LANG_FR = 1
    LANG_ES = 2
    LANG_ZH = 3
    LANG_PT = 4

    def __init__(
        self,
        robot,
        use_led=True,
        use_voice=True,
        use_robot_sound=False,
        use_pc_sound=True,
        sounds_dir="SON_FEEDBACK",
        pc_volume=0.8
    ):
        self.robot = robot
        self.use_led = use_led
        self.use_voice = use_voice
        self.use_robot_sound = use_robot_sound

        self.audio = AudioManager(
            sounds_dir=sounds_dir,
            enabled=use_pc_sound,
            volume=pc_volume
        )

    # ======================
    # LED
    # ======================
    def led_green(self):
        if not self.use_led:
            return
        try:
            self.robot.led_ring_solid([0, 255, 0])
        except Exception as e:
            print("[LED GREEN WARN]", e)

    def led_white(self):
        if not self.use_led:
            return
        try:
            self.robot.led_ring_solid([255, 255, 255])
        except Exception as e:
            print("[LED WHITE WARN]", e)

    def led_red_flashing(self):
        if not self.use_led:
            return
        try:
            self.robot.led_ring_flashing([255, 0, 0], period=0.3, iterations=0, wait=False)
        except Exception as e:
            print("[LED RED WARN]", e)

    def led_off(self):
        if not self.use_led:
            return
        try:
            self.robot.led_ring_turn_off()
        except Exception as e:
            print("[LED OFF WARN]", e)

    # ======================
    # VOIX NIRYO
    # ======================
    def say_fr(self, text: str):
        if not self.use_voice:
            return
        try:
            self.robot.say(text[:99], self.LANG_FR)
        except Exception as e:
            print("[SAY WARN]", e)

    # ======================
    # SONS NIRYO
    # ======================
    def set_robot_volume(self, volume_pct: int):
        if not self.use_robot_sound:
            return
        try:
            volume_pct = max(0, min(100, int(volume_pct)))
            self.robot.set_volume(volume_pct)
        except Exception as e:
            print("[ROBOT VOLUME WARN]", e)

    def list_robot_sounds(self):
        if not self.use_robot_sound:
            return []
        try:
            return self.robot.get_sounds()
        except Exception as e:
            print("[LIST ROBOT SOUNDS WARN]", e)
            return []

    def play_robot_sound(self, sound_name: str, wait_end=False):
        if not self.use_robot_sound:
            return
        try:
            self.robot.play_sound(sound_name, wait_end=wait_end)
        except Exception as e:
            print("[PLAY ROBOT SOUND WARN]", e)

    def stop_robot_sound(self):
        if not self.use_robot_sound:
            return
        try:
            self.robot.stop_sound()
        except Exception as e:
            print("[STOP ROBOT SOUND WARN]", e)

    # ======================
    # SONS PC
    # ======================
    def set_pc_volume(self, volume_0_to_1: float):
        self.audio.set_volume(volume_0_to_1)

    def list_pc_sounds(self):
        return self.audio.list_available_files()

    def play_pc_sound(self, sound_key_or_filename: str, wait_end=False, stop_previous=True):
        return self.audio.play(sound_key_or_filename, wait_end=wait_end, stop_previous=stop_previous)

    def stop_pc_sound(self):
        self.audio.stop()

    # Compatibilité avec ton ancien code
    def set_volume(self, volume_pct: int):
        self.set_pc_volume(max(0.0, min(1.0, volume_pct / 100.0)))

    def list_sounds(self):
        return self.list_pc_sounds()

    # ======================
    # ANNONCES PRÊTES
    # ======================
    def welcome_user(self, user_key: str):
        key = f"welcome_{user_key.lower().strip()}"
        ok = self.play_pc_sound(key)
        if not ok:
            print(f"[WELCOME WARN] Son d'accueil introuvable pour '{user_key}'")

    def manual_on(self):
        self.led_green()
        self.say_fr("Mode manuel activé")
        self.play_pc_sound("manual_on")

    def manual_off(self):
        self.led_white()
        self.say_fr("Mode manuel désactivé")
        self.play_pc_sound("manual_off")

    def estop_on(self):
        self.led_red_flashing()
        self.say_fr("Arrêt d'urgence activé")
        self.play_pc_sound("estop_on")

    def estop_off(self, manual_enabled: bool):
        if manual_enabled:
            self.led_green()
        else:
            self.led_white()
        self.say_fr("Arrêt d'urgence désactivé")
        self.play_pc_sound("estop_off")

    def conveyor_forward(self):
        self.play_pc_sound("conv_forward")

    def conveyor_backward(self):
        self.play_pc_sound("conv_backward")

    def conveyor_on(self):
        self.play_pc_sound("conv_on")

    def conveyor_off(self):
        self.play_pc_sound("conv_off")