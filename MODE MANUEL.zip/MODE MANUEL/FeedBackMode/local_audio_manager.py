from pathlib import Path
import threading

try:
    import pygame
    _PYGAME_OK = True
except ImportError:
    _PYGAME_OK = False


class AudioManager:
    """
    Gestionnaire audio local PC.
    Lit des fichiers audio (mp3, wav, ...) depuis un dossier local.
    """

    def __init__(self, sounds_dir="SON_FEEDBACK", enabled=True, volume=0.8):
        self.enabled = enabled
        self.base_dir = Path(__file__).resolve().parent
        self.sounds_dir = self.base_dir / sounds_dir
        self.volume = max(0.0, min(1.0, float(volume)))
        self._lock = threading.Lock()
        self._initialized = False

        self.sound_map = {
            "manual_on": "Mode_Manuel_Actif.mp3",
            "manual_off": "Mode_Manuel_Non_Actif.mp3",
            "estop_on": "Stop_Urgence.mp3",
            "estop_off": "Urgence_Desactivee.mp3",
            "conv_forward": "Convoyeur_En_Avant.mp3",
            "conv_backward": "Convoyeur_En_Arriere.mp3",
            "conv_on": "Convoyeur_Active.mp3",
            "conv_off": "Convoyeur_Desactive.mp3",
            
            "welcome_naoufel": "NAOUFEL.mp3",
            "welcome_yasmine": "YASMINE.mp3",
            "welcome_doussouba": "DOUSSOUBA.mp3",
            "welcome_emmanuel": "EMMANUEL.mp3",
            "welcome_amadou": "AMADOU.mp3",
        }

        if self.enabled:
            self._init_audio()

    def _init_audio(self):
        if not _PYGAME_OK:
            print("[AUDIO WARN] pygame n'est pas installé. Audio PC désactivé.")
            self.enabled = False
            return

        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init()
            pygame.mixer.music.set_volume(self.volume)
            self._initialized = True
            print("[AUDIO] Initialisation audio OK")
            print(f"[AUDIO] Dossier sons = {self.sounds_dir}")
        except Exception as e:
            print(f"[AUDIO WARN] Impossible d'initialiser pygame.mixer : {e}")
            self.enabled = False

    def set_volume(self, volume):
        self.volume = max(0.0, min(1.0, float(volume)))
        if self.enabled and self._initialized:
            try:
                pygame.mixer.music.set_volume(self.volume)
            except Exception as e:
                print(f"[AUDIO WARN] set_volume : {e}")

    def list_available_files(self):
        if not self.sounds_dir.exists():
            return []
        return sorted([p.name for p in self.sounds_dir.iterdir() if p.is_file()])

    def get_sound_path(self, sound_key_or_filename):
        filename = self.sound_map.get(sound_key_or_filename, sound_key_or_filename)
        return self.sounds_dir / filename

    def play(self, sound_key_or_filename, wait_end=False, stop_previous=True):
        if not self.enabled or not self._initialized:
            return False

        path = self.get_sound_path(sound_key_or_filename)

        if not path.exists():
            print(f"[AUDIO WARN] Fichier introuvable : {path}")
            return False

        with self._lock:
            try:
                if stop_previous:
                    pygame.mixer.music.stop()

                pygame.mixer.music.load(str(path))
                pygame.mixer.music.play()

                if wait_end:
                    while pygame.mixer.music.get_busy():
                        pygame.time.Clock().tick(20)

                return True

            except Exception as e:
                print(f"[AUDIO WARN] play('{path.name}') : {e}")
                return False

    def stop(self):
        if not self.enabled or not self._initialized:
            return
        try:
            pygame.mixer.music.stop()
        except Exception as e:
            print(f"[AUDIO WARN] stop : {e}")

    def is_busy(self):
        if not self.enabled or not self._initialized:
            return False
        try:
            return pygame.mixer.music.get_busy()
        except Exception:
            return False