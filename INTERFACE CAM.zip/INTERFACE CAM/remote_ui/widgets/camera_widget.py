from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import QLabel, QVBoxLayout, QWidget


class CameraWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)

        self.video_label = QLabel("CAM")
        self.video_label.setAlignment(Qt.AlignCenter)
        self.video_label.setStyleSheet("""
            QLabel {
                background-color: white;
                color: black;
                font-size: 32px;
                border: 2px solid black;
            }
        """)
        self.video_label.setMinimumSize(640, 360)

        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.video_label, alignment=Qt.AlignCenter)
        self.setLayout(layout)

    def update_frame(self, image):
        pixmap = QPixmap.fromImage(image)

        scaled = pixmap.scaled(
            self.video_label.size(),
            Qt.KeepAspectRatio,
            Qt.SmoothTransformation
        )

        self.video_label.setPixmap(scaled)

    def show_message(self, message):
        self.video_label.setPixmap(QPixmap())
        self.video_label.setText(message)

    def set_border_style(self, color="black", width=2):
        self.video_label.setStyleSheet(f"""
            QLabel {{
                background-color: white;
                color: black;
                font-size: 32px;
                border: {width}px solid {color};
            }}
        """)

    def resizeEvent(self, event):
        pixmap = self.video_label.pixmap()
        if pixmap and not pixmap.isNull():
            scaled = pixmap.scaled(
                self.video_label.size(),
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation
            )
            self.video_label.setPixmap(scaled)

        super().resizeEvent(event)