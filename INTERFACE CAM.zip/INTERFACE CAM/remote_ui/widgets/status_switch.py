from PySide6.QtCore import Qt, QRectF, Property, QPropertyAnimation, QEasingCurve
from PySide6.QtGui import QColor, QPainter, QPen, QBrush
from PySide6.QtWidgets import QWidget


class StatusSwitch(QWidget):
    def __init__(self, label="ETAT", active_color=QColor("green"), parent=None):
        super().__init__(parent)
        self.label = label
        self.active_color = active_color
        self.is_active = False
        self._offset = 0.0  # 0 = gauche, 1 = droite

        self.setMinimumSize(220, 80)

        self.anim = QPropertyAnimation(self, b"offset")
        self.anim.setDuration(220)
        self.anim.setEasingCurve(QEasingCurve.OutCubic)

    def get_offset(self):
        return self._offset

    def set_offset(self, value):
        self._offset = value
        self.update()

    offset = Property(float, get_offset, set_offset)

    def set_state(self, active: bool):
        target = 1.0 if active else 0.0

        self.is_active = active

        self.anim.stop()
        self.anim.setStartValue(self._offset)
        self.anim.setEndValue(target)
        self.anim.start()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        w = self.width()
        h = self.height()

        # Barre principale
        bar_x = 20
        bar_y = 10
        bar_w = w - 40
        bar_h = 30
        radius = 8

        outer_rect = QRectF(bar_x, bar_y, bar_w, bar_h)

        # Fond
        painter.setPen(QPen(Qt.black, 1.2))
        painter.setBrush(QBrush(QColor(120, 120, 120)))
        painter.drawRoundedRect(outer_rect, radius, radius)

        # Curseur mobile
        knob_w = bar_w / 2
        knob_x = bar_x + (bar_w - knob_w) * self._offset
        knob_rect = QRectF(knob_x, bar_y, knob_w, bar_h)

        # Couleur du curseur
        knob_color = self.active_color if self.is_active else QColor(230, 30, 30)

        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(knob_color))
        painter.drawRoundedRect(knob_rect, radius, radius)

        # Trait central de repère
        painter.setPen(QPen(QColor(40, 40, 40), 2))
        mid_x = int(bar_x + bar_w / 2)
        painter.drawLine(mid_x, bar_y + 2, mid_x, bar_y + bar_h - 2)

        # Contour final
        painter.setPen(QPen(Qt.black, 1.2))
        painter.setBrush(Qt.NoBrush)
        painter.drawRoundedRect(outer_rect, radius, radius)

        # Texte
        painter.setPen(Qt.black)
        painter.drawText(0, 48, w, 24, Qt.AlignCenter, self.label)