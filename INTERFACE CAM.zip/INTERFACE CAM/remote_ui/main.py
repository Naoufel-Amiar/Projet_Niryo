import sys
from PySide6.QtWidgets import QApplication

from app import RemoteUiMainWindow
from services.state_service import SimulatedStateService


def main():
    app = QApplication(sys.argv)

    window = RemoteUiMainWindow()
    state_service = SimulatedStateService()

    state_service.state_changed.connect(window.update_state)

    window.show()
    window.start_camera()
    state_service.start(2000)

    sys.exit(app.exec())


if __name__ == "__main__":
    main()