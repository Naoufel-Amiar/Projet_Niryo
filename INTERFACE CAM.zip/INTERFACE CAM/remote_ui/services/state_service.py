from PySide6.QtCore import QObject, QTimer, Signal
from models.state import RobotUiState


class SimulatedStateService(QObject):
    state_changed = Signal(object)

    def __init__(self, parent=None):
        super().__init__(parent)

        self._state = RobotUiState(
            operator_name="NOM OPERATEUR",
            camera_connected=False,
            manual_mode=False,
            emergency_mode=False,
            conveyor_active=False,
            conveyor_direction="STOP"
        )

        self._step = 0
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._update_simulation)

    def start(self, interval_ms=2000):
        self.state_changed.emit(self._state)
        self._timer.start(interval_ms)

    def stop(self):
        self._timer.stop()

    def _update_simulation(self):
        self._step += 1
        cycle = self._step % 6

        if cycle == 0:
            self._state.operator_name = "NOM OPERATEUR"
            self._state.manual_mode = False
            self._state.emergency_mode = False
            self._state.conveyor_active = False
            self._state.conveyor_direction = "STOP"

        elif cycle == 1:
            self._state.operator_name = "NAOUFEL"
            self._state.manual_mode = True
            self._state.emergency_mode = False
            self._state.conveyor_active = False
            self._state.conveyor_direction = "STOP"

        elif cycle == 2:
            self._state.manual_mode = True
            self._state.emergency_mode = False
            self._state.conveyor_active = True
            self._state.conveyor_direction = "LEFT"

        elif cycle == 3:
            self._state.manual_mode = True
            self._state.emergency_mode = False
            self._state.conveyor_active = True
            self._state.conveyor_direction = "RIGHT"

        elif cycle == 4:
            self._state.manual_mode = False
            self._state.emergency_mode = True
            self._state.conveyor_active = False
            self._state.conveyor_direction = "STOP"

        elif cycle == 5:
            self._state.manual_mode = False
            self._state.emergency_mode = False
            self._state.conveyor_active = False
            self._state.conveyor_direction = "STOP"

        self.state_changed.emit(self._state)