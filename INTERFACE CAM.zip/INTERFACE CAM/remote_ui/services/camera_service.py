import cv2

from PySide6.QtCore import QThread, Signal
from PySide6.QtGui import QImage


class CameraThread(QThread):
    frame_ready = Signal(QImage)
    error_signal = Signal(str)

    def __init__(self, camera_index=0, parent=None):
        super().__init__(parent)
        self.camera_index = camera_index
        self._running = False
        self._capture = None

    def run(self):
        # Sous Windows, CAP_DSHOW évite souvent certains soucis de webcam
        self._capture = cv2.VideoCapture(self.camera_index, cv2.CAP_DSHOW)

        if not self._capture.isOpened():
            self.error_signal.emit(f"Impossible d'ouvrir la caméra {self.camera_index}")
            return
        
        # self._capture.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
        # self._capture.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

        self._running = True

        while self._running:
            ret, frame = self._capture.read()

            if not ret:
                self.error_signal.emit("Lecture du flux caméra échouée")
                continue

            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            h, w, ch = frame.shape
            bytes_per_line = ch * w

            image = QImage(
                frame.data,
                w,
                h,
                bytes_per_line,
                QImage.Format_RGB888
            ).copy()

            self.frame_ready.emit(image)

        self._capture.release()

    def stop(self):
        self._running = False
        self.wait()