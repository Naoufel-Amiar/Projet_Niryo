from feedback.local_audio_manager import AudioManager


class RobotFeedback:
    def __init__(self, robot, use_led=True, use_voice=True, use_sound=True):
        self.robot = robot
        self.use_led = use_led
        self.use_voice = use_voice
        self.use_sound = use_sound

        self.audio = AudioManager(enabled=use_sound)

    # ======================
    # LED
    # ======================
    def led_green(self):
        if not self.use_led or self.robot is None:
            return
        try:
            self.robot.led_ring_solid([0, 255, 0])
        except Exception as e:
            print("[LED GREEN WARN]", e)

    def led_white(self):
        if not self.use_led or self.robot is None:
            return
        try:
            self.robot.led_ring_solid([255, 255, 255])
        except Exception as e:
            print("[LED WHITE WARN]", e)

    def led_red_flashing(self):
        if not self.use_led or self.robot is None:
            return
        try:
            self.robot.led_ring_flashing([255, 0, 0])
        except Exception as e:
            print("[LED RED FLASH WARN]", e)

    # ======================
    # AUDIO
    # ======================
    def play(self, key: str):
        if not self.use_sound:
            return
        self.audio.play(key)

    # ======================
    # EVENTS
    # ======================
    def manual_on(self):
        self.play("manual_on")
        self.led_green()

    def manual_off(self):
        self.play("manual_off")
        self.led_white()

    def estop_on(self):
        self.play("estop_on")
        self.led_red_flashing()

    def estop_off(self):
        self.play("estop_off")
        self.led_white()

    def conveyor_on(self):
        self.play("conv_on")

    def conveyor_off(self):
        self.play("conv_off")

    def conveyor_forward(self):
        self.play("conv_forward")

    def conveyor_backward(self):
        self.play("conv_backward")

    def gripper_open(self):
        self.play("gripper_open")

    def gripper_close(self):
        self.play("gripper_close")

    def welcome_operator(self, operator_key: str):
        if not self.use_sound:
            return

        key = f"welcome_{operator_key.lower()}"
        self.play(key)