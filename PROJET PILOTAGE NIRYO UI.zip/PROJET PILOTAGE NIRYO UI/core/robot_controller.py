import time

from pyniryo import (
    NiryoRobot,
    JointsPosition,
    ConveyorDirection,
)


class RobotController:
    def __init__(self, robot_ip: str, arm_velocity_percent: int = 100):
        self.robot_ip = robot_ip
        self.arm_velocity_percent = arm_velocity_percent

        self.robot = None
        self.conveyor_id = None

        self.gripper_closed = False
        self.gripper_busy = False
        self.last_toggle_time = 0.0

    def connect(self):
        self.robot = NiryoRobot(self.robot_ip)
        self.robot.set_learning_mode(False)
        self.robot.set_arm_max_velocity(self.arm_velocity_percent)

        try:
            self.robot.open_gripper()
            self.gripper_closed = False
        except Exception as e:
            print("[INIT GRIPPER WARN]", e)

        self.conveyor_id = self.detect_conveyor()

    def disconnect(self):
        if self.robot is None:
            return
        try:
            self.stop_all()
        except Exception:
            pass
        try:
            self.robot.close_connection()
        except Exception:
            pass

    def detect_conveyor(self):
        conv_ids = []
        try:
            conv_ids = self.robot.get_connected_conveyors_id()
        except Exception:
            conv_ids = []

        if conv_ids:
            return conv_ids[0]

        cid = None
        try:
            cid = self.robot.set_conveyor()
        except Exception:
            cid = None

        try:
            conv_ids = self.robot.get_connected_conveyors_id()
        except Exception:
            conv_ids = []

        if cid is not None:
            return cid
        if conv_ids:
            return conv_ids[0]
        return None

    def stop_all(self):
        try:
            if self.conveyor_id is not None:
                self.robot.stop_conveyor(self.conveyor_id)
        except Exception as e:
            print("[SAFE STOP WARN]", e)

    def move_from_qdot(self, qdot, robot_dt: float, eps_move: float):
        if self.robot is None:
            return

        try:
            q = list(self.robot.get_joints())
            q_target = [qi + vi * robot_dt for qi, vi in zip(q, qdot)]

            diff = max(abs(a - b) for a, b in zip(q_target, q))
            if diff >= eps_move:
                self.robot.move(JointsPosition(*q_target))
        except Exception as e:
            print("[MOVE WARN]", e)

    def set_conveyor(self, enabled: bool, speed_pct: int, direction: str):
        if self.robot is None or self.conveyor_id is None:
            return

        conv_dir = (
            ConveyorDirection.FORWARD
            if direction == "FWD"
            else ConveyorDirection.BACKWARD
        )

        try:
            self.robot.control_conveyor(self.conveyor_id, enabled, speed_pct, conv_dir)
        except Exception as e:
            print("[CONV WARN]", e)

    def toggle_gripper(self):
        if self.robot is None or self.gripper_busy:
            return

        self.gripper_busy = True
        try:
            if self.gripper_closed:
                print("[GRIPPER] opening...")
                self.robot.open_gripper()
                self.gripper_closed = False
                print("[GRIPPER] opened")
            else:
                print("[GRIPPER] closing...")
                self.robot.close_gripper()
                self.gripper_closed = True
                print("[GRIPPER] closed")
        except Exception as e:
            print("[GRIPPER WARN]", e)
        finally:
            self.gripper_busy = False
            self.last_toggle_time = time.time()