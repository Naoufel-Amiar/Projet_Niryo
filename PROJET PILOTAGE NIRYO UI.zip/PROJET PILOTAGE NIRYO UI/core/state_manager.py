from dataclasses import dataclass


@dataclass
class RobotSystemState:
    operator_name: str = "NOM OPERATEUR"
    camera_connected: bool = False

    manual_enabled: bool = True
    estop_active: bool = False

    conveyor_active: bool = False
    conveyor_direction: str = "STOP"

    gripper_closed: bool = False