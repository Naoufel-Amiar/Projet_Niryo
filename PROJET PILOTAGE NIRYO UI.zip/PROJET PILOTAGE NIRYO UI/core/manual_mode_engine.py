import threading
import time

from PySide6.QtCore import QObject, Signal

from hotas.mapper import HotasMapper
from core.robot_controller import RobotController
from core.state_manager import RobotSystemState
from ui.models.state import RobotUiState
from feedback.feedback import RobotFeedback


ROBOT_IP = "10.10.10.10"
ARM_MAX_VELOCITY_PERCENT = 100

MODE_COOLDOWN = 0.40
ESTOP_COOLDOWN = 0.40

ROBOT_HZ = 8.0
ROBOT_DT = 1.0 / ROBOT_HZ

DEADZONE = 0.05
EXPO = 1.6
BASE_SPEED = 4.0
EPS_MOVE = 0.0035

INV_TWIST = True
INV_Y = False
INV_X = True

HAT_MAP = {
    "UP": "UP",
    "DOWN": "DOWN",
    "LEFT": "LEFT",
    "RIGHT": "RIGHT",
    "NONE": "NONE",
}


def apply_deadzone(v: float, dz: float) -> float:
    return 0.0 if abs(v) < dz else v


def apply_expo(v: float, expo: float) -> float:
    s = 1.0 if v >= 0 else -1.0
    return s * (abs(v) ** expo)


def vec_norm_inf(vec) -> float:
    return max(abs(x) for x in vec)


class ManualModeEngine(QObject):
    def choose_operator(self):
        operators = {
            "1": ("naoufel", "Naoufel"),
            "2": ("yasmine", "Yasmine"),
            "3": ("doussouba", "Doussouba"),
            "4": ("emmanuel", "Emmanuel"),
            "5": ("amadou", "Amadou"),
        }

        print("\n=== Choix de l'opérateur ===")
        print("1 : Naoufel")
        print("2 : Yasmine")
        print("3 : Doussouba")
        print("4 : Emmanuel")
        print("5 : Amadou")

        while True:
            choice = input("Votre choix : ").strip()
            if choice in operators:
                self.operator_key, self.system_state.operator_name = operators[choice]
                print(f"[OPERATOR] sélectionné : {self.system_state.operator_name}")
                return
            print("Choix invalide, recommence.")

    state_changed = Signal(object)

    def __init__(self):
        super().__init__()

        self.running = False
        self.thread = None

        self.mapper = None
        self.robot_controller = RobotController(
            robot_ip=ROBOT_IP,
            arm_velocity_percent=ARM_MAX_VELOCITY_PERCENT,
        )

        self.system_state = RobotSystemState()
        self.system_state.operator_name = "Naoufel"

        self.operator_key = "naoufel"

        self.last_manual_btn = False
        self.last_estop_btn = False
        self.last_manual_toggle_time = 0.0
        self.last_estop_toggle_time = 0.0

        self.conv_enabled = False
        self.last_conv_cmd = {
            "on": None,
            "speed": None,
            "dir": None,
        }

        self.last_trigger = False
        self.gripper_cooldown = 0.45

        # Feedback
        self.feedback = None

        # Etats précédents pour éviter le spam audio / LED
        self.prev_manual_enabled = self.system_state.manual_enabled
        self.prev_estop_active = self.system_state.estop_active
        self.prev_conveyor_active = self.system_state.conveyor_active
        self.prev_conveyor_direction = self.system_state.conveyor_direction
        self.prev_gripper_closed = self.system_state.gripper_closed

    def start(self):
        if self.running:
            return

        print("[ENGINE] start")
        self.running = True

        self.choose_operator()
        self.emit_ui_state()

        self.mapper = HotasMapper()

        try:
            self.robot_controller.connect()
            print("[ENGINE] robot connected")
        except Exception as e:
            print("[ENGINE WARN] robot connection failed:", e)

        try:
            self.feedback = RobotFeedback(
                robot=self.robot_controller.robot,
                use_led=True,
                use_voice=True,
                use_sound=True,
            )
            self.feedback.welcome_operator(self.operator_key)
            print("[ENGINE] feedback ready")
        except Exception as e:
            self.feedback = None
            print("[ENGINE WARN] feedback init failed:", e)

        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()

    def stop(self):
        print("[ENGINE] stop")
        self.running = False

        try:
            self.robot_controller.disconnect()
        except Exception as e:
            print("[ENGINE WARN] robot disconnect failed:", e)

    def emit_ui_state(self):
        ui_state = RobotUiState(
            operator_name=self.system_state.operator_name,
            camera_connected=self.system_state.camera_connected,
            manual_mode=self.system_state.manual_enabled,
            emergency_mode=self.system_state.estop_active,
            conveyor_active=self.system_state.conveyor_active,
            conveyor_direction=self.system_state.conveyor_direction,
            gripper_closed=self.system_state.gripper_closed,
        )
        self.state_changed.emit(ui_state)

    def handle_mode_buttons(self, s):
        now = time.time()

        manual_btn = bool(s.manual_toggle)
        estop_btn = bool(s.estop_toggle)

        if (
            manual_btn
            and not self.last_manual_btn
            and (now - self.last_manual_toggle_time) > MODE_COOLDOWN
        ):
            self.system_state.manual_enabled = not self.system_state.manual_enabled
            self.last_manual_toggle_time = now
            print("[MODE] manual_enabled =", self.system_state.manual_enabled)

        if (
            estop_btn
            and not self.last_estop_btn
            and (now - self.last_estop_toggle_time) > ESTOP_COOLDOWN
        ):
            self.system_state.estop_active = not self.system_state.estop_active
            self.last_estop_toggle_time = now
            print("[MODE] estop_active =", self.system_state.estop_active)

        self.last_manual_btn = manual_btn
        self.last_estop_btn = estop_btn

    def compute_qdot(self, s, gain: float = 1.0):
        x_raw = getattr(s, "x", 0.0)
        y_raw = getattr(s, "y", 0.0)
        tw_raw = getattr(s, "twist", 0.0)

        if INV_X:
            x_raw = -x_raw
        if INV_Y:
            y_raw = -y_raw
        if INV_TWIST:
            tw_raw = -tw_raw

        x = apply_expo(apply_deadzone(x_raw, DEADZONE), EXPO)
        y = apply_expo(apply_deadzone(y_raw, DEADZONE), EXPO)
        tw = apply_expo(apply_deadzone(tw_raw, DEADZONE), EXPO)

        hat_in = getattr(s, "joy_dir", "NONE")
        hat = HAT_MAP.get(hat_in, "NONE")

        qdot = [0.0] * 6
        qdot[0] = tw * BASE_SPEED * gain
        qdot[1] = y * BASE_SPEED * gain
        qdot[2] = x * BASE_SPEED * gain

        step = 0.55 * BASE_SPEED * gain
        if hat == "UP":
            qdot[4] = +step
        elif hat == "DOWN":
            qdot[4] = -step
        elif hat == "RIGHT":
            qdot[3] = +step
        elif hat == "LEFT":
            qdot[3] = -step

        m = vec_norm_inf(qdot)
        limit = BASE_SPEED * gain
        if m > limit and m > 1e-9:
            scale = limit / m
            qdot = [v * scale for v in qdot]

        return qdot

    def handle_conveyor(self, s):
        if self.system_state.estop_active or not self.system_state.manual_enabled:
            if self.last_conv_cmd["on"] is not False:
                self.robot_controller.set_conveyor(False, 0, "FWD")
                self.last_conv_cmd = {"on": False, "speed": 0, "dir": "FWD"}

            self.system_state.conveyor_active = False
            self.system_state.conveyor_direction = "STOP"
            return

        thr_hat = getattr(s, "thr_hat", (0, 0))
        direction = getattr(s, "direction", "FWD")
        throttle_speed = getattr(s, "throttle_speed", 0.0)

        if thr_hat == (0, 1):
            self.conv_enabled = True
        elif thr_hat == (0, -1):
            self.conv_enabled = False

        speed_pct = max(0, min(100, int(throttle_speed * 100)))

        if not self.conv_enabled or speed_pct <= 0:
            if self.last_conv_cmd["on"] is not False:
                self.robot_controller.set_conveyor(False, 0, direction)
                self.last_conv_cmd = {"on": False, "speed": 0, "dir": direction}

            self.system_state.conveyor_active = False
            self.system_state.conveyor_direction = "STOP"
            return

        cmd_changed = (
            self.last_conv_cmd["on"] is not True
            or self.last_conv_cmd["speed"] != speed_pct
            or self.last_conv_cmd["dir"] != direction
        )

        if cmd_changed:
            self.robot_controller.set_conveyor(True, speed_pct, direction)
            self.last_conv_cmd = {
                "on": True,
                "speed": speed_pct,
                "dir": direction,
            }

        self.system_state.conveyor_active = True
        if direction == "FWD":
            self.system_state.conveyor_direction = "RIGHT"
        elif direction == "BWD":
            self.system_state.conveyor_direction = "LEFT"
        else:
            self.system_state.conveyor_direction = "STOP"

    def handle_gripper(self, s):
        if self.system_state.estop_active or not self.system_state.manual_enabled:
            return

        trigger_pressed = bool(getattr(s, "trigger", 0))
        now = time.time()

        if (
            trigger_pressed
            and not self.last_trigger
            and (now - self.robot_controller.last_toggle_time) > self.gripper_cooldown
        ):
            self.robot_controller.toggle_gripper()
            self.system_state.gripper_closed = self.robot_controller.gripper_closed
            print("[GRIPPER] closed =", self.system_state.gripper_closed)

            if self.feedback is not None:
                try:
                    if self.system_state.gripper_closed:
                        self.feedback.gripper_close()
                    else:
                        self.feedback.gripper_open()
                except Exception as e:
                    print("[GRIPPER FEEDBACK WARN]", e)
        self.last_trigger = trigger_pressed

    def handle_feedback_transitions(self):
        if self.feedback is None:
            return

        try:
            # ESTOP
            if self.system_state.estop_active != self.prev_estop_active:
                if self.system_state.estop_active:
                    self.feedback.estop_on()
                else:
                    self.feedback.estop_off()

            # MODE MANUEL
            if self.system_state.manual_enabled != self.prev_manual_enabled:
                if self.system_state.manual_enabled:
                    self.feedback.manual_on()
                else:
                    self.feedback.manual_off()

            # CONVOYEUR ON/OFF
            if self.system_state.conveyor_active != self.prev_conveyor_active:
                if self.system_state.conveyor_active:
                    self.feedback.conveyor_on()
                else:
                    self.feedback.conveyor_off()

            # CONVOYEUR SENS
            if (
                self.system_state.conveyor_active
                and self.system_state.conveyor_direction != self.prev_conveyor_direction
            ):
                if self.system_state.conveyor_direction == "RIGHT":
                    self.feedback.conveyor_forward()
                elif self.system_state.conveyor_direction == "LEFT":
                    self.feedback.conveyor_backward()

        except Exception as e:
            print("[FEEDBACK WARN]", e)

        self.prev_manual_enabled = self.system_state.manual_enabled
        self.prev_estop_active = self.system_state.estop_active
        self.prev_conveyor_active = self.system_state.conveyor_active
        self.prev_conveyor_direction = self.system_state.conveyor_direction
        self.prev_gripper_closed = self.system_state.gripper_closed

    def _loop(self):
        while self.running:
            try:
                s = self.mapper.read()

                self.handle_mode_buttons(s)
                self.handle_conveyor(s)

                if self.system_state.estop_active or not self.system_state.manual_enabled:
                    self.system_state.gripper_closed = self.robot_controller.gripper_closed
                    self.handle_feedback_transitions()
                    self.emit_ui_state()
                    time.sleep(0.05)
                    continue

                qdot = self.compute_qdot(s)
                self.robot_controller.move_from_qdot(
                    qdot=qdot,
                    robot_dt=ROBOT_DT,
                    eps_move=EPS_MOVE,
                )

                self.handle_gripper(s)

                self.system_state.gripper_closed = self.robot_controller.gripper_closed

                self.handle_feedback_transitions()
                self.emit_ui_state()

            except Exception as e:
                print("[ENGINE LOOP WARN]", e)

            time.sleep(0.05)