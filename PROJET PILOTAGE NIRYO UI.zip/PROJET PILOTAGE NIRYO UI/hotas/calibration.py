import pygame

def clamp01(x: float) -> float:
    return max(0.0, min(1.0, x))

def calibrate_axis(device, axis_idx: int):
    """
    Calibration interactive min/max pour transformer un axe en valeur 0..1
    sur toute la course, même si l'axe passe par 0 au milieu.
    """
    input(f"\n[CALIB] Mets le rail TOUT EN BAS puis Entrée...")
    pygame.event.pump()
    v_min = device.get_axis(axis_idx)

    input(f"[CALIB] Mets le rail TOUT EN HAUT puis Entrée...")
    pygame.event.pump()
    v_max = device.get_axis(axis_idx)

    if abs(v_max - v_min) < 1e-6:
        raise RuntimeError("Calibration invalide (min=max). Recommence.")

    print(f"[CALIB OK] axis[{axis_idx}] min={v_min:+.3f} max={v_max:+.3f}")
    return v_min, v_max

def axis_to_01(v: float, v_min: float, v_max: float) -> float:
    return clamp01((v - v_min) / (v_max - v_min))