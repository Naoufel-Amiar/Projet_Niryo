import pygame
from dataclasses import dataclass
from .devices import get_joy_thr
from .calibration import calibrate_axis, axis_to_01

def hat_to_cardinal(hat_xy):
    x, y = hat_xy
    if x == 0 and y == 0:
        return "NONE"
    if abs(y) >= abs(x):
        return "UP" if y > 0 else "DOWN"
    return "RIGHT" if x > 0 else "LEFT"

@dataclass
class HotasState:
    # joystick
    x: float
    y: float
    twist: float
    joy_hat: tuple
    joy_dir: str
    trigger: int

    # throttle
    throttle_raw: float
    throttle_speed: float
    thr_hat: tuple
    direction: str  # "FWD" / "BWD"

    # NOUVEAUX BOUTONS
    manual_toggle: int
    estop_toggle: int

class HotasMapper:
    """
    Lecture HOTAS : T.16000M + TWCS
    - throttle_speed: 0..1 (calibré)
    - direction: mémorisée via HAT throttle (gauche = BWD, droite = FWD)
    """
    def __init__(
        self,
        calibrate: bool = True,
        print_devices: bool = True,
        # mapping indices (tu peux les overrider si besoin)
        ax_x: int = 0,
        ax_y: int = 1,
        ax_twist: int = 2,
        joy_hat_index: int = 0,
        joy_trigger_btn: int = 0,
        thr_throttle_axis: int = 2,
        thr_hat_index: int = 0,

        joy_manual_toggle_btn: int = 2,
        joy_estop_toggle_btn: int = 3,
    ):
        self.joy, self.thr = get_joy_thr()

        if print_devices:
            print("[HOTAS] Joystick :", self.joy.get_name())
            print("[HOTAS] Throttle :", self.thr.get_name() if self.thr else "None")

        # mapping
        self.AX_X = ax_x
        self.AX_Y = ax_y
        self.AX_TWIST = ax_twist
        self.JOY_HAT_INDEX = joy_hat_index
        self.JOY_TRIGGER_BTN = joy_trigger_btn
        self.THR_THROTTLE_AXIS = thr_throttle_axis
        self.THR_HAT_INDEX = thr_hat_index

        self.JOY_MANUAL_TOGGLE_BTN = joy_manual_toggle_btn
        self.JOY_ESTOP_TOGGLE_BTN = joy_estop_toggle_btn

        # état direction latch
        self.direction_state = "FWD"

        # calibration throttle
        self.thr_min = None
        self.thr_max = None
        if self.thr and calibrate:
            self.thr_min, self.thr_max = calibrate_axis(self.thr, self.THR_THROTTLE_AXIS)

    def read(self) -> HotasState:
        pygame.event.pump()

        # joystick
        x = self.joy.get_axis(self.AX_X) if self.AX_X < self.joy.get_numaxes() else 0.0
        y = self.joy.get_axis(self.AX_Y) if self.AX_Y < self.joy.get_numaxes() else 0.0
        twist = self.joy.get_axis(self.AX_TWIST) if self.AX_TWIST < self.joy.get_numaxes() else 0.0

        joy_hat = self.joy.get_hat(self.JOY_HAT_INDEX) if self.joy.get_numhats() > 0 else (0, 0)
        joy_dir = hat_to_cardinal(joy_hat)

        trigger = self.joy.get_button(self.JOY_TRIGGER_BTN) if self.JOY_TRIGGER_BTN < self.joy.get_numbuttons() else 0

        manual_toggle = (
            self.joy.get_button(self.JOY_MANUAL_TOGGLE_BTN)
            if self.JOY_MANUAL_TOGGLE_BTN < self.joy.get_numbuttons()
            else 0
        )

        estop_toggle = (
            self.joy.get_button(self.JOY_ESTOP_TOGGLE_BTN)
            if self.JOY_ESTOP_TOGGLE_BTN < self.joy.get_numbuttons()
            else 0
        )

        # throttle
        throttle_raw = 0.0
        throttle_speed = 0.0
        thr_hat = (0, 0)

        if self.thr:
            throttle_raw = self.thr.get_axis(self.THR_THROTTLE_AXIS) if self.THR_THROTTLE_AXIS < self.thr.get_numaxes() else 0.0

            if self.thr_min is not None:
                throttle_speed = axis_to_01(throttle_raw, self.thr_min, self.thr_max)

            thr_hat = self.thr.get_hat(self.THR_HAT_INDEX) if self.thr.get_numhats() > 0 else (0, 0)
            hx, hy = thr_hat
            if hx < 0:
                self.direction_state = "BWD"
            elif hx > 0:
                self.direction_state = "FWD"

        return HotasState(
            x=x, y=y, twist=twist,
            joy_hat=joy_hat, joy_dir=joy_dir, trigger=trigger,
            throttle_raw=throttle_raw, throttle_speed=throttle_speed,
            thr_hat=thr_hat, direction=self.direction_state,
            manual_toggle=manual_toggle,
            estop_toggle=estop_toggle,
        )