import pygame

JOY_NAME_HINTS = ["T.16000", "T16000", "T-16000", "Thrustmaster T.16000"]
THR_NAME_HINTS = ["TWCS", "Throttle"]

def _pick_device(devices, hints):
    for j in devices:
        name = j.get_name().lower()
        if any(h.lower() in name for h in hints):
            return j
    return None

def init_pygame():
    pygame.init()
    pygame.joystick.init()

def list_devices():
    devices = []
    for i in range(pygame.joystick.get_count()):
        j = pygame.joystick.Joystick(i)
        j.init()
        devices.append(j)
    return devices

def get_joy_thr():
    """
    Retourne (joy, thr). thr peut être None si pas trouvé.
    """
    init_pygame()
    devices = list_devices()
    if not devices:
        raise RuntimeError("Aucun joystick détecté. Vérifie USB + pilotes.")

    joy = _pick_device(devices, JOY_NAME_HINTS) or devices[0]
    thr = _pick_device(devices, THR_NAME_HINTS)
    return joy, thr