from pathlib import Path
from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QFrame,
    QStackedLayout,
    QComboBox,
    QPushButton,
)

from PySide6.QtGui import QIcon

from ui.widgets.status_switch import StatusSwitch
from ui.models.state import RobotUiState
from ui.widgets.camera_widget import CameraWidget
from ui.services.selection_camera_service import QtCameraManager


class RemoteUiMainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        icon_path = Path(__file__).resolve().parents[1] / "assets" / "icone_robot.ico"
        self.setWindowIcon(QIcon(str(icon_path)))

        self.setWindowTitle("Niryo Control Station")
        self.setWindowIcon(QIcon("assets/icone_robot.ico"))
        self.resize(1000, 700)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        central_widget.setStyleSheet("""
            QWidget {
                background-color: #dcdcdc;
            }
        """)

        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(30, 20, 30, 20)
        main_layout.setSpacing(20)
        central_widget.setLayout(main_layout)

        self.operator_label = QLabel("NOM OPERATEUR")
        self.operator_label.setAlignment(Qt.AlignCenter)
        self.operator_label.setStyleSheet("""
            QLabel {
                font-size: 28px;
                font-weight: bold;
            }
        """)
        main_layout.addWidget(self.operator_label)

        top_layout = QHBoxLayout()
        top_layout.setSpacing(40)
        main_layout.addLayout(top_layout)

        # ===== Colonne gauche =====
        left_column = QVBoxLayout()
        left_column.setSpacing(35)
        top_layout.addLayout(left_column, 1)

        self.manual_switch = StatusSwitch("MODE MANUEL")
        self.emergency_switch = StatusSwitch("MODE URGENCE")
        self.gripper_switch = StatusSwitch("ETAT PINCE")

        left_column.addWidget(self.manual_switch)
        left_column.addWidget(self.emergency_switch)
        left_column.addWidget(self.gripper_switch)
        left_column.addStretch()

        # ===== Colonne droite =====
        right_column = QVBoxLayout()
        top_layout.addLayout(right_column, 2)

                # ===== Sélecteur caméra =====
        camera_select_layout = QHBoxLayout()
        camera_select_layout.setSpacing(12)

        self.camera_selector_label = QLabel("Caméra :")
        self.camera_selector_label.setStyleSheet("""
            QLabel {
                font-size: 17px;
                font-weight: bold;
                color: #111111;
                padding-bottom: 2px;
            }
        """)

        self.camera_selector = QComboBox()
        self.camera_selector.setMinimumWidth(200)

        self.camera_selector.setStyleSheet("""
            QComboBox {
                background-color: white;
                color: #111111;
                border: 2px solid #1f1f1f;
                border-radius: 10px;
                padding: 8px 40px 8px 14px;
                font-size: 15px;
                font-weight: 600;
                min-height: 36px;
            }

            QComboBox:hover {
                border: 2px solid #2c5aa0;
                background-color: #f8fbff;
            }

            QComboBox:focus {
                border: 2px solid #2c5aa0;
                background-color: #f4f8ff;
            }

            QComboBox::drop-down {
                subcontrol-origin: padding;
                subcontrol-position: top right;
                width: 34px;
                border-left: 2px solid #1f1f1f;
                background-color: #f1f1f1;
                border-top-right-radius: 8px;
                border-bottom-right-radius: 8px;
            }

            QComboBox::drop-down:hover {
                background-color: #e7eefc;
            }

            QComboBox::down-arrow {
                width: 12px;
                height: 12px;
            }

            QComboBox QAbstractItemView {
                background-color: white;
                color: #111111;
                border: 2px solid #1f1f1f;
                border-radius: 8px;
                padding: 4px;
                selection-background-color: #dbe8ff;
                selection-color: black;
                outline: 0px;
                font-size: 14px;
                font-weight: 500;
            }
        """)

        self.refresh_camera_button = QPushButton("Actualiser")
        self.refresh_camera_button.setStyleSheet("""
            QPushButton {
                background-color: white;
                color: #111111;
                border: 2px solid #1f1f1f;
                border-radius: 10px;
                padding: 8px 14px;
                font-size: 14px;
                font-weight: bold;
                min-height: 36px;
            }

            QPushButton:hover {
                background-color: #f4f8ff;
                border: 2px solid #2c5aa0;
            }

            QPushButton:pressed {
                background-color: #dbe8ff;
            }
        """)

        camera_select_layout.addWidget(self.camera_selector_label)
        camera_select_layout.addWidget(self.camera_selector, 1)
        camera_select_layout.addWidget(self.refresh_camera_button)

        right_column.addLayout(camera_select_layout)

        self.camera_frame = QFrame()
        self.camera_frame.setFrameShape(QFrame.Box)
        self.camera_frame.setLineWidth(2)
        self.camera_frame.setMinimumSize(0, 0)
        self.camera_frame.setStyleSheet("""
            QFrame {
                background-color: white;
                border: 2px solid black;
            }
        """)

        # Layout interne du cadre caméra
        camera_layout = QVBoxLayout()
        camera_layout.setContentsMargins(0, 0, 0, 0)
        camera_layout.setSpacing(0)

        self.camera_container = QWidget()
        self.camera_container.setStyleSheet("background: transparent;")

        self.camera_stack = QStackedLayout()
        self.camera_stack.setStackingMode(QStackedLayout.StackAll)
        self.camera_container.setLayout(self.camera_stack)

        # Fond = flux caméra
        self.camera_widget = CameraWidget()

        # Overlay urgence
        self.alert_overlay = QWidget()
        self.alert_overlay.setStyleSheet("background: transparent;")
        self.alert_overlay.hide()

        overlay_layout = QVBoxLayout()
        overlay_layout.setContentsMargins(12, 12, 12, 12)
        overlay_layout.setSpacing(0)
        self.alert_overlay.setLayout(overlay_layout)

        self.alert_label = QLabel("⛔ ARRET D'URGENCE ⛔")
        self.alert_label.setAlignment(Qt.AlignCenter)
        self.alert_label.setStyleSheet("""
            QLabel {
                font-size: 28px;
                font-weight: bold;
                color: white;
                background-color: rgb(200, 0, 0);
                border: 2px solid black;
                padding: 10px;
            }
        """)

        overlay_layout.addWidget(self.alert_label, alignment=Qt.AlignTop)
        overlay_layout.addStretch()

        self.camera_stack.addWidget(self.camera_widget)
        self.camera_stack.addWidget(self.alert_overlay)

        camera_layout.addWidget(self.camera_container, alignment=Qt.AlignCenter)
        self.camera_frame.setLayout(camera_layout)

        right_column.addWidget(self.camera_frame)
        right_column.addStretch()

        # ===== Partie basse =====
        conveyor_layout = QVBoxLayout()
        conveyor_layout.setSpacing(10)
        main_layout.addLayout(conveyor_layout)

        arrows_layout = QHBoxLayout()
        arrows_layout.setSpacing(50)

        self.left_arrow = QLabel("←")
        self.left_arrow.setAlignment(Qt.AlignCenter)
        self.left_arrow.setStyleSheet("""
            QLabel {
                font-size: 140px;
                color: gray;
            }
        """)

        self.right_arrow = QLabel("→")
        self.right_arrow.setAlignment(Qt.AlignCenter)
        self.right_arrow.setStyleSheet("""
            QLabel {
                font-size: 140px;
                color: gray;
            }
        """)

        arrows_layout.addStretch()
        arrows_layout.addWidget(self.left_arrow)
        arrows_layout.addWidget(self.right_arrow)
        arrows_layout.addStretch()

        conveyor_layout.addLayout(arrows_layout)

        self.conveyor_switch = StatusSwitch("ETAT TAPIS")
        conveyor_layout.addWidget(self.conveyor_switch, alignment=Qt.AlignCenter)

        # ===== Timer urgence =====
        self._emergency_flash_on = False
        self.emergency_timer = QTimer(self)
        self.emergency_timer.timeout.connect(self._toggle_emergency_flash)

        self.camera_manager = QtCameraManager()
        self.camera_manager.frame_ready.connect(self.camera_widget.update_frame)
        self.camera_manager.error_signal.connect(self.camera_widget.show_message)
        self.camera_manager.cameras_changed.connect(self.populate_camera_selector)

        self.camera_selector.currentIndexChanged.connect(self.on_camera_selected)
        self.refresh_camera_button.clicked.connect(self.camera_manager.refresh_cameras)
        self.camera_manager.refresh_cameras()

    def populate_camera_selector(self, camera_names):
        self.camera_selector.blockSignals(True)
        self.camera_selector.clear()

        if not camera_names:
            self.camera_selector.addItem("Aucune caméra détectée")
            self.camera_selector.setEnabled(False)
        else:
            self.camera_selector.addItems(camera_names)
            self.camera_selector.setEnabled(True)
            self.camera_selector.setCurrentIndex(0)

        self.camera_selector.blockSignals(False)

        if camera_names:
            self.camera_manager.start_camera(0)

    def on_camera_selected(self, index):
        if index < 0:
            return
        self.camera_manager.switch_camera(index)

    def update_state(self, state: RobotUiState):
        self.operator_label.setText(state.operator_name)

        self.manual_switch.set_state(state.manual_mode)
        self.emergency_switch.set_state(state.emergency_mode)
        self.conveyor_switch.set_state(state.conveyor_active)
        self.gripper_switch.set_state(state.gripper_closed)

        self.set_emergency_visual(state.emergency_mode)

        if state.emergency_mode:
            self.left_arrow.setStyleSheet("""
                QLabel {
                    font-size:140px;
                    color:red;
                }
            """)
            self.right_arrow.setStyleSheet("""
                QLabel {
                    font-size:140px;
                    color:red;
                }
            """)
            return

        if state.conveyor_direction == "LEFT":
            self.left_arrow.setStyleSheet("""
                QLabel {
                    font-size:140px;
                    color:limegreen;
                }
            """)
            self.right_arrow.setStyleSheet("""
                QLabel {
                    font-size:140px;
                    color:gray;
                }
            """)

        elif state.conveyor_direction == "RIGHT":
            self.left_arrow.setStyleSheet("""
                QLabel {
                    font-size:140px;
                    color:gray;
                }
            """)
            self.right_arrow.setStyleSheet("""
                QLabel {
                    font-size:140px;
                    color:limegreen;
                }
            """)

        else:
            self.left_arrow.setStyleSheet("""
                QLabel {
                    font-size:140px;
                    color:gray;
                }
            """)
            self.right_arrow.setStyleSheet("""
                QLabel {
                    font-size:140px;
                    color:gray;
                }
            """)

    def set_emergency_visual(self, active: bool):
        if active:
            self.alert_overlay.show()

            if not self.emergency_timer.isActive():
                self._emergency_flash_on = False
                self.emergency_timer.start(350)

            self._toggle_emergency_flash()

        else:
            self.emergency_timer.stop()
            self.alert_overlay.hide()

            # self.camera_frame.setStyleSheet("""
            #     QFrame {
            #         background-color: transparent;
            #         border: none;
            #     }
            # """)
            self.camera_widget.set_border_style("black", 2)

            self.alert_label.setStyleSheet("""
                QLabel {
                    font-size: 28px;
                    font-weight: bold;
                    color: white;
                    background-color: rgb(200, 0, 0);
                    border: 2px solid black;
                    padding: 10px;
                }
            """)

    def _toggle_emergency_flash(self):
        self._emergency_flash_on = not self._emergency_flash_on

        if self._emergency_flash_on:
            self.camera_widget.set_border_style("red", 5)
            self.alert_label.setStyleSheet("""
                QLabel {
                    font-size: 28px;
                    font-weight: bold;
                    color: white;
                    background-color: rgb(255, 0, 0);
                    border: 3px solid black;
                    padding: 10px;
                }
            """)
        else:
            self.camera_widget.set_border_style("#780000", 5)
            self.alert_label.setStyleSheet("""
                QLabel {
                    font-size: 28px;
                    font-weight: bold;
                    color: white;
                    background-color: rgb(140, 0, 0);
                    border: 3px solid black;
                    padding: 10px;
                }
            """)

    def closeEvent(self, event):
        try:
            if hasattr(self, "emergency_timer") and self.emergency_timer.isActive():
                self.emergency_timer.stop()
        except Exception as e:
            print("[UI CLOSE WARN] emergency_timer:", e)

        try:
            if hasattr(self, "camera_manager"):
                self.camera_manager.stop_camera()
        except Exception as e:
            print("[UI CLOSE WARN] camera_manager:", e)

        try:
            if hasattr(self, "engine"):
                self.engine.stop()
        except Exception as e:
            print("[UI CLOSE WARN] engine:", e)

        super().closeEvent(event)