from PySide6.QtCore import QObject, Signal
from PySide6.QtGui import QImage
from PySide6.QtMultimedia import (
    QMediaDevices,
    QCamera,
    QMediaCaptureSession,
    QVideoSink,
)


class QtCameraManager(QObject):
    frame_ready = Signal(QImage)
    error_signal = Signal(str)
    cameras_changed = Signal(list)

    def __init__(self, parent=None):
        super().__init__(parent)

        self.media_devices = QMediaDevices()
        self.capture_session = QMediaCaptureSession()
        self.video_sink = QVideoSink()

        self.capture_session.setVideoSink(self.video_sink)
        self.video_sink.videoFrameChanged.connect(self._on_video_frame_changed)

        self.camera = None
        self.available_cameras = []

        self.refresh_cameras()

        # Si des caméras sont branchées/débranchées
        self.media_devices.videoInputsChanged.connect(self.refresh_cameras)

    def refresh_cameras(self):
        self.available_cameras = QMediaDevices.videoInputs()
        names = [cam.description() for cam in self.available_cameras]
        self.cameras_changed.emit(names)

    def get_camera_names(self):
        return [cam.description() for cam in self.available_cameras]

    def start_camera(self, index: int):
        if not self.available_cameras:
            self.error_signal.emit("Aucune caméra détectée")
            return

        if index < 0 or index >= len(self.available_cameras):
            self.error_signal.emit(f"Index caméra invalide : {index}")
            return

        self.stop_camera()

        camera_device = self.available_cameras[index]
        self.camera = QCamera(camera_device)
        self.capture_session.setCamera(self.camera)
        self.camera.start()

    def stop_camera(self):
        if self.camera is not None:
            self.camera.stop()
            self.camera.deleteLater()
            self.camera = None

    def switch_camera(self, index: int):
        self.start_camera(index)

    def _on_video_frame_changed(self, frame):
        if not frame.isValid():
            return

        image = frame.toImage()
        if image.isNull():
            return

        self.frame_ready.emit(image.copy())