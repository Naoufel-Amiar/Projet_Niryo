from dataclasses import dataclass

@dataclass
class RobotUiState:
    operator_name: str = "NOM OPERATEUR"
    camera_connected: bool = False
    manual_mode: bool = False
    emergency_mode: bool = False
    conveyor_active: bool = False
    conveyor_direction: str = "STOP"   # LEFT / RIGHT / STOP
    gripper_closed: bool = False