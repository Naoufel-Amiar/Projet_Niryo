import sys
from pathlib import Path
from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QIcon

from ui.main_window import RemoteUiMainWindow
from core.manual_mode_engine import ManualModeEngine


def main():
    app = QApplication(sys.argv)

    icon_path = Path(__file__).resolve().parent / "assets" / "icone_robot.ico"
    app.setWindowIcon(QIcon(str(icon_path)))

    window = RemoteUiMainWindow()
    engine = ManualModeEngine()

    window.engine = engine
    engine.state_changed.connect(window.update_state)

    def cleanup():
        try:
            engine.stop()
        except Exception as e:
            print("[APP CLEANUP WARN] engine:", e)

    app.aboutToQuit.connect(cleanup)

    window.show()
    engine.start()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()